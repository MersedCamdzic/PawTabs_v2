const s={async get(t){return(await chrome.storage.local.get(t))[t]},async getMany(t){return await chrome.storage.local.get(t)},async set(t,e){await chrome.storage.local.set({[t]:e})},async update(t,e){const r=await this.get(t),a=e(r);return await this.set(t,a),a},async remove(t){await chrome.storage.local.remove(t)}};export{s as storage};
//# sourceMappingURL=storage-iPyVs1zu.js.map
